from lookup import NSLookup

obj = NSLookup()
output = obj.look('www.microsoft.com')
print(output)