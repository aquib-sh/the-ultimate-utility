from qr import QR

code_object = QR()
path = code_object.create('https://www.twitter.com/shaikhaquib394')
