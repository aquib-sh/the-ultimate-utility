from lookup import IPLookup

obj = IPLookup()
print(obj.look('74.125.225.229'))